﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mikroszim.Entities
{
    class DeathProbability
    {
        public Gender Gender { get; set; }
        public int BirthYear { get; set; }
        public double DProbability { get; set; }

    }
}
